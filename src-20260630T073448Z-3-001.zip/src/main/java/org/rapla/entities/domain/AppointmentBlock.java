/*--------------------------------------------------------------------------*
 | Copyright (C) 2011 Christopher Kohlhaas                                  |
 |                                                                          |
 | This program is free software; you can redistribute it and/or modify     |
 | it under the terms of the GNU General Public License as published by the |
 | Free Software Foundation. A copy of the license has been included with   |
 | these distribution in the COPYING file, if not go to www.fsf.org         |
 |                                                                          |
 | As a special exception, you are granted the permissions to link this     |
 | program with every library, which license fulfills the Open Source       |
 | Definition as published by the Open Source Initiative (OSI).             |
 *--------------------------------------------------------------------------*/
package org.rapla.entities.domain;

import org.rapla.components.util.DateTools;
import org.rapla.components.util.TimeInterval;

import java.time.LocalDateTime;
import java.util.Date;



/**
 * This class represents a time block of an appointment.
 * @since Rapla 1.4
 */
public class AppointmentBlock implements Comparable<AppointmentBlock>
{
    long start;
    long end;
    boolean isException;
    private final Appointment	appointment;
	
	/**
	 * Basic constructor
	 */
	public AppointmentBlock(long start, long end, Appointment appointment, boolean isException)
	{
		this.start = start;
		this.end = end;
		this.appointment = appointment;
		this.isException = isException;
	}
	static public AppointmentBlock create(Appointment appointment)
	{
		return new AppointmentBlock(appointment);
	}
	
	protected AppointmentBlock(Appointment appointment)
	{
	    this(appointment.getStart().getTime(),appointment.getEnd().getTime(), appointment, false);
	}
	
	public boolean includes(AppointmentBlock a2)
	{
	    return start <= a2.start  &&  end>= a2.end;
	}
	
	public boolean intersects(AppointmentBlock a2)
    {
        return start < a2.end  &&  end> a2.start;
    }
    
	
	/**
	 * Returns the start date of this block
	 * 
	 * @return Date
	 */
	public long getStart()
	{
		return start;
	}
	
	/**
	 * Returns the end date of this block
	 * 
	 * @return Date
	 */
	public long getEnd()
	{
		return end;
	}

	public LocalDateTime getStartDateTime() {
		return DateTools.toLocalDateTime(start);
	}

	public LocalDateTime getEndDateTime() {
		return DateTools.toLocalDateTime(end);
	}


	/**
     * Returns if the block is an exception from the appointment rule
     * 
     */
    public boolean isException()
    {
        return isException;
    }
	/**
	 * Returns the appointment to which this block belongs
	 * 
	 * @return Appointment
	 */
	public Appointment getAppointment()
	{
		return appointment;
	}
	
	/**
     * This method is used to compare two appointment blocks by their start dates
     */
	public int compareTo(AppointmentBlock other) 
	{
        if (other.start > start)
            return -1;
        if (other.start < start) 
            return 1;
        if (other.end > end)
            return 1;
        if (other.end < end)
            return -1;
        if ( other == this)
        {
            return 0;
        }
        @SuppressWarnings("unchecked")
		int compareTo = appointment.compareTo(other.appointment);
		return compareTo;
    }
	
	public boolean equals( Object obj)
	{
	    if ( obj == this)
	    {
	        return true;
	    }
	    AppointmentBlock other = (AppointmentBlock) obj;
	    if ( other.start != start || other.end != end)
	    {
	        return false;
	    }
	    return appointment.equals( other.appointment);
	}
	
	
	public String toString()
	{
        final String startDate = DateTools.formatDateTime(new Date(start));
        final String endDate = DateTools.formatDateTime(new Date(end));
        return startDate + " - " + endDate;
	}

	public TimeInterval toInterval()
	{
		return new TimeInterval(new Date(getStart()), new Date(getEnd()));
	}

    
}
